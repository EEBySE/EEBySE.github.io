<?php
   require('fpdf16/fpdf.php');
   $pdf=new FPDF();	
   $pdf->AddPage();	//Agregar una pagina
   $pdf->SetFont('Arial','B',14);	//Letra Arial, negrita (Bold), tam. 20
     
   include("conexion.php"); 
   $link=Conectarse(); 
   $result=mysql_query("select id_pelicula,titulo,director,actor,imagen from pelicula",$link);

   $pdf->SetFont('Arial','B',20);	//Letra Arial, negrita (Bold), tam. 20
   $pdf->Cell(190,40,'Videoteca',0,1,'C');
   
   $pdf->SetFont('Arial','',10);	
   $pos=40+18;
   while($row = mysql_fetch_array($result)) { 
      $id=$row["id_pelicula"];
      $ti=$row["titulo"];
      $di=$row["director"];
      $ac=$row["actor"];
	  $im=$row["imagen"];
	  $pdf->Cell(40,10,"",0,0,'L');
	  $pdf->Image("MisImagenes/$im",40,"$pos",10,15);
	 $pos=$pos+30;
	  
      $pdf->Cell(10,30,$id,0,0,'L');
      $pdf->Cell(40,30,$ti,0,0,'L');
	  $pdf->Cell(40,30,$di,0,0,'L');
	  $pdf->Cell(40,30,$ac,0,0,'L');
      $pdf->Cell(40,30,$im,0,1,'L');
	  
	//  if ($pos>200) $pos=37;
	 
     //  $pdf->Cell(0,10,$id.'   '.$ti.'    '.$di.'   '.$ac,1,1,'L');
	 //$pdf->Cell(10,10,'Estamos viendo',1,1,'C'); 


   } 
 
 $pdf->Output();
  mysql_free_result($result); 
  mysql_close($link);
?>
